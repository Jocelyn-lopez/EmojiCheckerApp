package com.avneetksethi.emojichecker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class QueryConfirmation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_queryconfirmation);

        TextView confirmationTextView = (TextView) findViewById(R.id.confirmationTextView);

    }
}
